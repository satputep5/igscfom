<div id="footer">
	<div class="col-lg-12">
		<div class="text-center margin-top-10 margin-bottom-10">
			<p class="margin-top-10">&copy; FOM Hochschule</p>
		</div>
	</div>
</div>
<script>
    // tooltip demo
    $('.tooltip-demo').tooltip({
        selector: "[data-toggle=tooltip]",
        container: "body"
    })
    </script>