<footer>
        <div class="row no-margin">
          <div class="container">
            <div class="col-md-12">
              <p class="heading-white">GET in touch</p>
            </div>
            <div class="col-md-4">
              <p><strong>Indira Global Study Center (IGSC) - Campus</strong></p>
              <p><strong>Address:</strong> 85/5-B, Samanvay IT Campus, New Pune, Mumbai Highway, Tathawade, Pune, Maharashtra 411033.</p>
              <p><strong>Email:</strong> <a href="mailto:igsc@indiraedu.com">igsc@indiraedu.com</a></p>
              <p><strong>Phone No.:</strong> 9834743394 / 9834743399 / 9834743368</p>
              <p><strong>Website:</strong> <a href="http://www.indiraigsc.in" target="_blank">http://www.indiraigsc.in </a></p>
            </div>

            <div class="col-md-4">
              <p><strong>Indira Global Study Center (IGSC) - Admission Office</strong></p>
              <p><strong>Address:</strong>  Z- 3 Himali Society, Erandavane, Pune 411004 </p>
              <p><strong>Email:</strong> <a href="mailto:igsc@indiraedu.com">igsc@indiraedu.com</a></p>
              <p><strong>Phone No.:</strong> 9834743394 / 9834743399 / 9834743368</p>
              <p><strong>Website:</strong> <a href="http://www.indiraigsc.in" target="_blank">http://www.indiraigsc.in</a></p>
            </div>

            <div class="col-md-4">
              <p><strong>FOM University of Applied Sciences</strong></p>
              <p><strong>Address:</strong> Herkulesstrasse 32, 45127 Essen Germany.</p>
              <p><strong>Contact Person:</strong> Lena Runge, MA</p>
              <p><strong>International Office</strong></p>
              <p><strong>Tel Desk:</strong> +49 201 81004-733</p>
              <p><strong>Email:</strong> <a href="mailto:india@fom.de">india@fom.de</a></p>
              <p><strong>Website:</strong> <a href="http://www.fom.de" target="_blank">http://www.fom.de</a></p>
            </div>

            <div class="col-md-12">
              <hr>
              <p class="copyright">&copy; Indira Global Study Center (IGSC). All rights reserved.</p>
              <p class="ojaswi"><a href="http://www.ojaswitech.com/" target="_blank">Web Design Company</a> - Ojaswi Tech</p>
            </div>            
          </div>
        </div>
      </footer>