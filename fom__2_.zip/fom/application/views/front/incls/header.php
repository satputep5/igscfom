 <header>
        <div class="container">
          <div class="logo">
            <img src="<?php echo base_url(); ?>images/fom-logo.jpg" alt="FOM Hochschule" title="FOM Hochschule" class="fom-logo img-responsive">
            <img src="<?php echo base_url(); ?>images/indira-logo.jpg" alt="Indira Global Study Center (IGSC)" title="Indira Global Study Center (IGSC)" class="igsc-logo img-responsive">
            <div class="clear"></div>
          </div>
        </div>        
      </header>